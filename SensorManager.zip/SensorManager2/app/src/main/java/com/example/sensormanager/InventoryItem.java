package com.example.sensormanager;

public class InventoryItem {
    private int id;
    private String name;
    private int quantity;
    private String location;

    public InventoryItem(int id, String name, int quantity, String location) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.location = location;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public String getLocation() { return location; }

    // Setters
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setName(String name) { this.name = name; }
    public void setLocation(String location) { this.location = location; }
}
